/*******************************************************************************

    uBlock Origin - a comprehensive, efficient content blocker
    Copyright (C) 2017-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import { hostnameCompare, isHnRegexOrPath } from './make-utils.js';
import { literalStrFromRegex } from './regex-analyzer.js';
import { safeReplace } from './safe-replace.js';

/******************************************************************************/

const resourceDetails = new Map();
const resourceAliases = new Map();
const worldTemplate = {
    args: new Map(),
    arglists: new Map([['',0]]),
    hostnames: new Map(),
    regexesOrPaths: new Map(),
    matches: new Set(),
    hasEntities: false,
    hasAncestors: false,
};
const worlds = {
    ISOLATED: structuredClone(worldTemplate),
    MAIN: structuredClone(worldTemplate),
};
const frameworkTemplate = {
    scriptletFunctions: new Map(),
    allFunctions: new Map(),
};
const worldFrameworks = {
    ISOLATED: structuredClone(frameworkTemplate),
    MAIN: structuredClone(frameworkTemplate),
};

/******************************************************************************/

function createScriptletCoreCode(allFunctions, resourceEntry) {
    allFunctions.set(resourceEntry.name, resourceEntry.code);
    if ( Boolean(resourceEntry.dependencies?.length) === false ) { return; }
    const dependencies = resourceEntry.dependencies.slice();
    while ( dependencies.length !== 0 ) {
        const token = dependencies.shift();
        const details = resourceDetails.get(token);
        if ( details === undefined ) { continue; }
        if ( allFunctions.has(details.name) ) { continue; }
        allFunctions.set(details.name, details.code);
        if ( Array.isArray(details.dependencies) === false ) { continue; }
        dependencies.push(...details.dependencies);
    }
}

/******************************************************************************/

function compileBroadExclusion(details) {
    if ( Boolean(details.excludeMatches?.length) === false ) { return; }
    for ( const worldDetails of Object.values(worlds) ) {
        for ( const hn of details.excludeMatches ) {
            if ( isHnRegexOrPath(hn) ) {
                const refs = worldDetails.regexesOrPaths.get(hn) ?? new Set();
                if ( refs.size === 0 ) {
                    worldDetails.regexesOrPaths.set(hn, refs);
                }
                refs.add(0);
                continue;
            }
            const refs = worldDetails.hostnames.get(hn) ?? new Set();
            if ( refs.size === 0 ) {
                worldDetails.hostnames.set(hn, refs);
            }
            refs.add(0);
        }
    }
}

/******************************************************************************/

export function reset() {
    worlds.ISOLATED = structuredClone(worldTemplate);
    worlds.MAIN = structuredClone(worldTemplate);
}

export function resetFramework() {
    reset();
    worldFrameworks.ISOLATED = structuredClone(frameworkTemplate);
    worldFrameworks.MAIN = structuredClone(frameworkTemplate);
}

export function resetAll() {
    resetFramework();
    resourceDetails.clear();
    resourceAliases.clear();
}

/******************************************************************************/

export function compile(rulesetId, details) {
    if ( details.args.length === 0 ) {
        return compileBroadExclusion(details);
    }
    if ( details.args[0].endsWith('.js') === false ) {
        details.args[0] += '.js';
    }
    if ( resourceAliases.has(details.args[0]) ) {
        details.args[0] = resourceAliases.get(details.args[0]);
    }
    const scriptletToken = details.args[0];
    const resourceEntry = resourceDetails.get(scriptletToken);
    if ( resourceEntry === undefined ) {
        console.log(`make-scriptlets.js / compile(): Can't find ${scriptletToken} scriptlet`);
        return;
    }
    if ( resourceEntry.requiresTrust && details.trustedSource !== true ) {
        console.log(`Rejecting +js(${details.args.join()}): ${rulesetId} is not trusted`);
        return;
    }
    const worldDetails = worlds[resourceEntry.world];
    const { allFunctions, scriptletFunctions } = worldFrameworks[resourceEntry.world];
    if ( scriptletFunctions.has(resourceEntry.name) === false ) {
        scriptletFunctions.set(resourceEntry.name, scriptletFunctions.size);
        createScriptletCoreCode(allFunctions, resourceEntry);
    }
    // Convert args to arg indices
    const arglist = details.args.slice();
    arglist[0] = scriptletFunctions.get(resourceEntry.name);
    for ( let i = 1; i < arglist.length; i++ ) {
        const arg = arglist[i];
        if ( worldDetails.args.has(arg) === false ) {
            worldDetails.args.set(arg, worldDetails.args.size);
        }
        arglist[i] = worldDetails.args.get(arg);
    }
    const arglistKey = JSON.stringify(arglist).slice(1, -1);
    if ( worldDetails.arglists.has(arglistKey) === false ) {
        worldDetails.arglists.set(arglistKey, worldDetails.arglists.size);
    }
    const arglistIndex = worldDetails.arglists.get(arglistKey);
    if ( details.matches ) {
        for ( const hn of details.matches ) {
            if ( isHnRegexOrPath(hn) ) {
                worldDetails.matches.clear();
                worldDetails.matches.add('*');
                if ( worldDetails.regexesOrPaths.has(hn) === false ) {
                    worldDetails.regexesOrPaths.set(hn, new Set());
                }
                worldDetails.regexesOrPaths.get(hn).add(arglistIndex);
                continue;
            }
            const isEntity = hn.endsWith('.*') || hn.endsWith('.*>>');
            worldDetails.hasEntities ||= isEntity;
            const isAncestor = hn.endsWith('>>')
            worldDetails.hasAncestors ||= isAncestor;
            if ( isEntity || isAncestor ) {
                worldDetails.matches.clear();
                worldDetails.matches.add('*');
            }
            if ( worldDetails.matches.has('*') === false ) {
                worldDetails.matches.add(hn);
            }
            if ( worldDetails.hostnames.has(hn) === false ) {
                worldDetails.hostnames.set(hn, new Set());
            }
            worldDetails.hostnames.get(hn).add(arglistIndex);
        }
    } else {
        worldDetails.matches.add('*');
    }
    if ( details.excludeMatches ) {
        for ( const hn of details.excludeMatches ) {
            if ( isHnRegexOrPath(hn) ) {
                if ( worldDetails.regexesOrPaths.has(hn) === false ) {
                    worldDetails.regexesOrPaths.set(hn, new Set());
                }
                worldDetails.regexesOrPaths.get(hn).add(~arglistIndex);
                continue;
            }
            if ( worldDetails.hostnames.has(hn) === false ) {
                worldDetails.hostnames.set(hn, new Set());
            }
            worldDetails.hostnames.get(hn).add(~arglistIndex);
        }
    }
}

/******************************************************************************/

export function commit(rulesetId, template, secret) {
    const stats = {};
    for ( const world of Object.keys(worlds) ) {
        const worldDetails = worlds[world];
        const { args, arglists } = worldDetails;
        const hostnames = Array.from(worldDetails.hostnames).toSorted((a, b) =>
            hostnameCompare(a[0], b[0])
        ).map(a => ([ a[0], JSON.stringify(Array.from(a[1]).map(a => JSON.parse(a))).slice(1,-1)]));
        const scriptletFromRegexes = Array.from(worldDetails.regexesOrPaths)
            .filter(a => a[0].startsWith('/') && a[0].endsWith('/'))
            .map(a => {
                const restr = a[0].slice(1,-1);
                return [
                    literalStrFromRegex(restr).slice(0,8),
                    restr,
                    JSON.stringify(Array.from(a[1])).slice(1,-1),
                ];
            }).flat();
        if ( hostnames.length === 0 && scriptletFromRegexes.length === 0 ) { continue; }
        let content = safeReplace(template, 'self.$scriptletSecret$', JSON.stringify(secret));
        content = safeReplace(content, 'self.$hasHostnames$', JSON.stringify(hostnames.length !== 0));
        content = safeReplace(content, 'self.$hasEntities$', JSON.stringify(worldDetails.hasEntities));
        content = safeReplace(content, 'self.$hasAncestors$', JSON.stringify(worldDetails.hasAncestors));
        content = safeReplace(content, 'self.$hasRegexes$', JSON.stringify(scriptletFromRegexes.length !== 0));
        content = safeReplace(content,
            'self.$scriptletFromRegexes$',
            `/* ${worldDetails.regexesOrPaths.size} */ ${JSON.stringify(scriptletFromRegexes)}`
        );
        content = safeReplace(content,
            'self.$scriptletHostnames$',
            `/* ${hostnames.length} */ ${JSON.stringify(hostnames.map(a => a[0]))}`
        );
        content = safeReplace(content,
            'self.$scriptletArglistRefs$',
            `/* ${hostnames.length} */ ${JSON.stringify(hostnames.map(a => a[1]))}`
        );
        content = safeReplace(content,
            'self.$scriptletArglists$',
            `/* ${arglists.size} */ ${JSON.stringify(Array.from(arglists.keys()))}`
        );
        content = safeReplace(content,
            'self.$scriptletArgs$',
            `/* ${args.size} */ ${JSON.stringify(Array.from(args.keys()))}`
        );
        content = safeReplace(content, /\$rulesetId\$/, rulesetId, 0);
        stats[world] = {
            code: content,
            hostnames: Array.from(worldDetails.matches).sort(),
            hasRegexes: scriptletFromRegexes.length !== 0,
            hasAncestors: worldDetails.hasAncestors,
            hasEntities: worldDetails.hasEntities,
        };
    }
    return stats;
}

/******************************************************************************/

export function commitFramework(beginTemplate, endTemplate, secret) {
    const stats = {};
    for ( const world of Object.keys(worldFrameworks) ) {
        const { scriptletFunctions, allFunctions } = worldFrameworks[world];
        let beginCode = safeReplace(beginTemplate, 'self.$scriptletSecret$', JSON.stringify(secret));
        beginCode = safeReplace(beginCode, 'self.$scriptletFunctionRefs$',
            `/* ${scriptletFunctions.size} */ [${Array.from(scriptletFunctions.keys()).join(',')}]`
        );
        beginCode = safeReplace(beginCode, 'self.$scriptletFunctions$',
            Array.from(allFunctions.values()).sort((a, b) => {
                if ( a.startsWith('function zeta_') ) {
                    if ( b.startsWith('function zeta_') ) {
                        const amatch = /[^ ]+\n/.exec(a);
                        const bmatch = /[^ ]+\n/.exec(b);
                        return amatch[0].localeCompare(bmatch[0]);
                    }
                }
                return a.localeCompare(b);
            }).join('\n\n')
        );
        let endCode = safeReplace(endTemplate, 'self.$scriptletSecret$', JSON.stringify(secret));
        stats[world] = { beginCode, endCode };
    }
    return stats;
}

/******************************************************************************/

export function importScriptlet(details) {
    const funcBody = details.code.replace(/\/\*.+?\*\//gs, '').trim();
    const funcName = `zeta_${globalThis.crypto.randomUUID().replaceAll('-', '')}`;
    const { name } = details;
    const code = /^function\s+[^(]+\(.*?\)\s*\{.*\}$/s.test(funcBody)
        ? `function ${funcName}(...args) { // ${name}\n(${funcBody})(...args)\n}`
        : `function ${funcName}() { // ${name}\n${funcBody}\n}`;
    const entry = { name: funcName, code, world: details.world ?? 'MAIN',
        requiresTrust: details.requiresTrust === true,
    };
    if ( Array.isArray(details.dependencies) ) {
        entry.dependencies = [ ...details.dependencies ];
    }
    resourceDetails.set(name, entry);
    if ( Array.isArray(details.aliases) ) {
        for ( const alias of details.aliases ) {
            resourceAliases.set(alias, funcName);
        }
    } else if ( typeof details.alias === 'string' ) {
        resourceAliases.set(details.alias, funcName);
    } else if ( Array.isArray(details.alias) ) {
        for ( const alias of details.alias ) {
            resourceAliases.set(alias, funcName);
        }
    }
}

/******************************************************************************/

export function init(scriptlets) {
    for ( const scriptlet of scriptlets ) {
        const { name, aliases, fn } = scriptlet;
        const entry = {
            name: fn.name,
            code: fn.toString(),
            world: scriptlet.world || 'MAIN',
            dependencies: scriptlet.dependencies,
            requiresTrust: scriptlet.requiresTrust === true,
        };
        resourceDetails.set(name, entry);
        if ( Array.isArray(aliases) === false ) { continue; }
        for ( const alias of aliases ) {
            resourceAliases.set(alias, name);
        }
    }
}

/******************************************************************************/
